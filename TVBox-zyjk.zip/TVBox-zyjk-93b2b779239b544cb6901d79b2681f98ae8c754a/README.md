# TVbox自用接口

1、给英文不好的朋友

GitHub 中文化插件 🔰https://greasyfork.org/zh-CN/scripts/435208

Github 增强-高速下载 🔰https://greasyfork.org/zh-CN/scripts/412245

2、Github RAW 加速服务

源码 https://gitcdn.top/https://github.com/用户名/仓库名/raw/main/接口文件

香港 https://raw.iqiq.io/用户名/仓库名/main/接口文件

新加坡 https://raw.kgithub.com/用户名/仓库名/main/接口文件

日本 

https://fastly.jsdelivr.net/gh/用户名/仓库名@main/接口文件

https://cdn.staticaly.com/gh/用户名/仓库名/main/接口文件

https://raw.fastgit.org/用户名/仓库名/main/接口文件

韩国

https://ghproxy.com/https://raw.githubusercontent.com/用户名/仓库名/main/接口文件

https://ghproxy.net/https://raw.githubusercontent.com/用户名/仓库名/main/接口文件

https://gcore.jsdelivr.net/gh/用户名/仓库名@main/接口文件

https://raw.githubusercontents.com/用户名/仓库名/main/接口文件

3，Github 静态加速

https://cdn.staticaly.com/gh/用户名/仓库名/main/接口文件

https://cdn.jsdelivr.net/gh/用户名/仓库名@main/接口文件

https://purge.jsdelivr.net/gh/用户名/仓库名@main/接口文件

4、EGP源

http://epg.51zmt.top:8000/e.xml

https://epg.112114.xyz/pp.xml

以下为地址

epg-DIYP接口1：(hhttp://epg.51zmt.top:8000/api/diyp/)

epg-DIYP接口2：(http://diyp.112114.xyz/)

epg-DIYP接口3：(https://epg.hicloud.co/epg.php/)

epg1：(https://epg.sec.st/epg.php/)

epg3：(https://epg.pm/)

epg4：(http://n33426t756.wicp.vip/diyp/epg.php/)

epg5：(http://www.diyp.top/diyp/epg.php/)

总epg：(http://epg.51zmt.top:8000/e.xml/)

央视及各省卫视epg：(http://epg.51zmt.top:8000/cc.xml/)

地方及数字付费epg：(http://epg.51zmt.top:8000/difang.xml/)

港澳台及海外epg：(http://epg.51zmt.top:8000/gat.xml/)

epg6：(http://124.223.212.38:83/)

epg7：(https://epg.112114.xyz/)

[超级直播](https://epg.112114.xyz/epginfo)

[Xml格式](https://epg.112114.xyz/pp.xml)

[Xml格式](https://epg.112114.xyz/pp.xml.gz)


5、开源仓库

https://github.com/

https://gitlab.com/

https://gitee.com/

https://coding.net/

https://gitcode.net/

https://gitea.com/   仓库名是 mao,tvbox,box,tv等类似的，有几率出现 1.删除仓库 2.删除用户 3.封禁账户 4.黑名单

https://agit.ai/

https://notabug.org/

6、短地址平台

（1）https://short.io

（2）http://88d.cn

（3）https://77url.com

（4）https://suowo.cn

（5）https://6du.in

（6）https://www.urlc.cn

（7）https://59z.cn

（8）https://suowo.cn

（9）https://0a.fit/

（10）https://www.urlc.cn/

7、TVBox各路大佬配置（排名不分先后）：

（1）唐三：https://hutool.ml/tang

（2）Fongmi：https://raw.fastgit.org/FongMi/CatVodSpider/main/json/config.json

（3）俊于：http://home.jundie.top:81/top98.json

（4）饭太硬：http://饭太硬.ga/x/o.json

（5）霜辉月明py：https://ghproxy.com/raw.githubusercontent.com/lm317379829/PyramidStore/pyramid/py.json

（6）小雅dr：http://drpy.site/js1

（7）菜妮丝：https://tvbox.cainisi.cf

（8）神器：https://神器每日推送.tk/pz.json

（9）巧技：http://pandown.pro/tvbox/tvbox.json

（10）刚刚：http://刚刚.live/猫

（11）吾爱有三：http://52bsj.vip:98/0805

（12）潇洒：https://download.kstore.space/download/2863/01.txt

（13）佰欣园：https://ghproxy.com/https://raw.githubusercontent.com/chengxueli818913/maoTV/main/44.txt

（14）胖虎：https://notabug.org/imbig66/tv-spider-man/raw/master/配置/0801.json

（15）云星日记：https://maoyingshi.cc/tiaoshizhushou/1.txt

（16）Yoursmile7：https://agit.ai/Yoursmile7/TVBox/raw/branch/master/XC.json

（17）BOX：http://52bsj.vip:81/api/v3/file/get/29899/box2.json?sign=3cVyKZQr3lFAwdB3HK-A7h33e0MnmG6lLB9oWlvSNnM%3D%3A0

（18）哔哩学习：http://52bsj.vip:81/api/v3/file/get/41063/bili.json?sign=TxuApYZt6bNl9TzI7vObItW34UnATQ4RQxABAEwHst4%3D%3A0

（19）UndCover：https://raw.githubusercontent.com/UndCover/PyramidStore/main/py.json

（20）木极：https://pan.tenire.com/down.php/2664dabf44e1b55919f481903a178cba.txt

（21）Ray：https://dxawi.github.io/0/0.json

（22）甜蜜：https://kebedd69.github.io/TVbox-interface/py甜蜜.json

（23）52bsj：http://52bsj.vip:81/api/v3/file/get/29899/box2.json?sign=3cVyKZQr3lFAwdB3HK-A7h33e0MnmG6lLB9oWlvSNnM%3D%3A0

（24）肥猫：http://我不是.肥猫.love:63

8、随机轮换壁纸：

（1）https://bing.img.run/rand.php

（2）http://www.kf666888.cn/api/tvbox/img

（3）https://picsum.photos/1280/720/?blur=10

（4）http://刚刚.live/图

（5）http://饭太硬.ga/深色壁纸/api.php

（6）https://www.dmoe.cc/random.php

（7）https://api.btstu.cn/sjbz/zsy.php

（8）https://api.btstu.cn/sjbz/?lx=dongman

（9）http://api.btstu.cn/sjbz/?lx=meizi

（10）http://api.btstu.cn/sjbz/?lx=suiji

（11）https://pictures.catvod.eu.org/

9、工具

（1）文本处理： http://www.txttool.com/

本页面只是收集Box，自用请勿宣传。

所有资源全部搜集于网络